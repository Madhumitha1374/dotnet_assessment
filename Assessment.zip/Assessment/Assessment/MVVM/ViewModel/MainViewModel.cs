﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assessment.MVVM.ViewModel
{
    
        

public class MainViewModel : INotifyPropertyChanged
    {
        private object _currentView;

        public object CurrentView
        {
            get => _currentView;
            set
            {
                _currentView = value;
                OnPropertyChanged(nameof(CurrentView));
            }
        }

        public RelayCommand AddNewUserCommand { get; }
        public RelayCommand AllUsersCommand { get; }
        public RelayCommand MapViewCommand { get; }

        public MainViewModel()
        {
            AddNewUserCommand = new RelayCommand(_ => CurrentView = new AddNewUserViewModel(this));
            AllUsersCommand = new RelayCommand(_ => CurrentView = new AllUsersViewModel(this));
            MapViewCommand = new RelayCommand(_ => CurrentView = new MapViewModel());
            CurrentView = new AllUsersViewModel(this); // Default view
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
