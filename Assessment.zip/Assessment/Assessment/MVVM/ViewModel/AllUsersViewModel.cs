﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assessment.MVVM.Model;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;

namespace Assessment.MVVM.ViewModel
{
    

    public class AllUsersViewModel : INotifyPropertyChanged
    {
        private readonly MainViewModel _mainViewModel;
        public ObservableCollection<UserModel> Users { get; }
        private UserModel _selectedUser;

        public UserModel SelectedUser
        {
            get => _selectedUser;
            set
            {
                _selectedUser = value;
                OnPropertyChanged(nameof(SelectedUser));
            }
        }

        public ICommand AddNewUserCommand { get; }

        public AllUsersViewModel(MainViewModel mainViewModel)
        {
            _mainViewModel = mainViewModel;
            Users = new ObservableCollection<UserModel>();
            AddNewUserCommand = new RelayCommand(_ => _mainViewModel.CurrentView = new AddNewUserViewModel(_mainViewModel));
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

}
