﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assessment.MVVM.Model;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;

namespace Assessment.MVVM.ViewModel
{
   

    public class AddNewUserViewModel : INotifyPropertyChanged
    {
        private readonly MainViewModel _mainViewModel;
        public UserModel User { get; set; }
        public ObservableCollection<UserModel> Users { get; }

        public ICommand SaveCommand { get; }

        public AddNewUserViewModel(MainViewModel mainViewModel)
        {
            _mainViewModel = mainViewModel;
            User = new UserModel();
            Users = new ObservableCollection<UserModel>();
            SaveCommand = new RelayCommand(_ => SaveUser());
        }

        private void SaveUser()
        {
            Users.Add(User);
            _mainViewModel.CurrentView = new AllUsersViewModel(_mainViewModel); // Go back to All Users view
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

}
