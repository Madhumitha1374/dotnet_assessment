﻿using Last.ViewModel;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Last.View
{
    public partial class AddNewUserView : UserControl
    {
        public AddNewUserView()
        {
            InitializeComponent();
            DataContext = new AddNewUserViewModel();
        }

        private void SelectProfilePicture_Click(object sender, RoutedEventArgs e)
        {
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
        }

    }
}
