﻿using Last.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Last.View
{
    public partial class MapView : UserControl
    {
        private double zoomFactor = 1.0;
        public MapView()
        {

            InitializeComponent();

        }

        private void ZoomIn_Click(object sender, RoutedEventArgs e)
        {
            zoomFactor += 0.1; 
            ApplyZoom();
        }

        private void ZoomOut_Click(object sender, RoutedEventArgs e)
        {
            if (zoomFactor > 0.1) 
            {
                zoomFactor -= 0.1; 
            }
            ApplyZoom();
        }

        private void ApplyZoom()
        {
            scaleTransform.ScaleX = zoomFactor; 
            scaleTransform.ScaleY = zoomFactor; 
        }

        

    }
}
