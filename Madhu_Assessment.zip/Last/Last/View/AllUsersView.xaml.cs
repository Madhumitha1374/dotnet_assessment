﻿using Last.Model;
using Last.ViewModel;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Last.View
{
    public partial class AllUsersView : UserControl
    {
        public AllUsersView()
        {
            InitializeComponent();
           this.DataContext = new AllUsersViewModel();

        }
        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (UsersDataGrid.SelectedItem is User selectedUser)
            {
                var viewModel = (MainViewModel)Application.Current.MainWindow.DataContext;
                viewModel.SelectedUser = selectedUser;
            }

        }


    }
}
