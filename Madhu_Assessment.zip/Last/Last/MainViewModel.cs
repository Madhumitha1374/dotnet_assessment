﻿using Last.Model;
using Last.View;
using Last.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;


namespace Last
{
    public class MainViewModel: INotifyPropertyChanged
    {
        private ObservableCollection<User> _users;
        public ObservableCollection<User> Users { get; set; }
        private bool _isSidebarOpen = true;
        private object _currentView;
        private User _selectedUser;

        public User SelectedUser
        {
            get => _selectedUser;
            set
            {
                _selectedUser = value;
                OnPropertyChanged(nameof(SelectedUser));
            }
        }


        public bool IsSidebarOpen
        {
            get => _isSidebarOpen;
            set
            {
                _isSidebarOpen = value;
                OnPropertyChanged(nameof(IsSidebarOpen));
            }
        }



        public object CurrentView
        {
            get => _currentView;
            set
            {
                _currentView = value;
                OnPropertyChanged(nameof(CurrentView));
            }
        }


        public ICommand AddNewUserCommand { get; }

        public ICommand AllUsersCommand { get; }
        public ICommand ToggleSideMenuCommand { get; }
        public ICommand MapViewCommand { get; }

       
        private void OpenAddNewUserView()
        {
            CurrentView = new AddNewUserView(); 
        }
        public ICommand CloseCommand { get; }

        public AllUsersViewModel AllUsersViewModel { get; private set; }

        public MainViewModel()
        {
            Users = new ObservableCollection<User>();
             CloseCommand = new RelayCommand(CloseApplication);
            ToggleSideMenuCommand = new RelayCommand(ToggleSideMenu);
            AddNewUserCommand = new RelayCommand(OpenAddNewUserView);
            AllUsersCommand = new RelayCommand(OpenAllUsersView);
            MapViewCommand = new RelayCommand(OpenMapView);
            AllUsersViewModel = new AllUsersViewModel();
        }

        private void OpenAllUsersView()
        {
            CurrentView = new AllUsersView();
        }

        private void OpenMapView()
        {
            CurrentView = new MapView(); 
        }



        private void ToggleSideMenu()
        {
            
            IsSidebarOpen = !IsSidebarOpen;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName]string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

       
        private void CloseApplication()
        {
            System.Windows.Application.Current.Shutdown();
        }
    }

    public class RelayCommand : ICommand
    {
        private readonly Action _execute;
        private readonly Func<bool> _canExecute;

        public RelayCommand(Action execute, Func<bool> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute();
        }

        public void Execute(object parameter)
        {
            _execute();
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }


}
