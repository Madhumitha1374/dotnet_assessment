﻿using Last.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Windows;
using System.Data.Common;

namespace Last.ViewModel
{

    public class AllUsersViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<User> _users;
        public ObservableCollection<User> Users
        {
            get => _users;
            set
            {
                _users = value;
                OnPropertyChanged(nameof(Users));
            }
        }

        public ICommand LoadUsersCommand { get; }

        public AllUsersViewModel()
        {
            Users = new ObservableCollection<User>();
            LoadUsers();
            
        }

        private User _selectedUser;

        public User SelectedUser
        {
            get => _selectedUser;
            set
            {
                _selectedUser = value;
                OnPropertyChanged(nameof(SelectedUser));
            }
        }

        public void OnUserSelected(User user)
        {
            SelectedUser = user;
        }


        private void LoadUsers()
        {
           
            
            //MessageBox.Show("1 successfully.");
            if(Users == null)
            {
                MessageBox.Show("collection is not initialised");
            }
            string c = "Data source = KRISHNA\\sqlexpress; Initial catalog = SagarDB; Integrated security = true";
            SqlConnection connection = new SqlConnection(c);

            try
            {

                connection.Open();

                string query = "SELECT Name, Age, DateOfBirth, ContactNumber, ProfilePicture  FROM Users";

                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();
                //MessageBox.Show("2. Success");

                if (!reader.HasRows)
                {
                    //MessageBox.Show("No users found in the database.");
                    return;
                }

                //MessageBox.Show("Users found, reading data...");

                while (reader.Read())
                {
                    var name = reader[0];
                    var age = reader[1]; 
                    var dateOfBirth = reader[2]; 
                    var contactNumber = reader[3]; 
                    var photo = reader[4];


                    Users.Add(new User
                    {
                        Name = name.ToString(),
                        Age = Convert.ToInt32(age),
                        DateOfBirth = Convert.ToDateTime(dateOfBirth),
                        ContactNumber = contactNumber.ToString(),
                        ProfilePicture = photo as byte[]
                    });
                }
                //MessageBox.Show("Image retrieved successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }

        }



       
    

    public event PropertyChangedEventHandler PropertyChanged;
    protected virtual void OnPropertyChanged(string propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
}



