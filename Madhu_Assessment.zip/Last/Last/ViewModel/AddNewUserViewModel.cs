﻿using Last.Model;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.IO;
using System.Collections;


namespace Last.ViewModel
{
    public class AddNewUserViewModel : INotifyPropertyChanged
    {
        

        private User _newUser;

        public User NewUser
        {
            get => _newUser;
            set
            {
                _newUser = value;
                OnPropertyChanged(nameof(NewUser));
            }
        }

        public ICommand SaveUserCommand { get; set; }
        public ICommand LoadProfilePictureCommand { get; set; }

        public ICommand CapturePhotoCommand { get; set; }

        public AddNewUserViewModel()
        {
            NewUser = new User();
            SaveUserCommand = new RelayCommand(SaveUser);
            LoadProfilePictureCommand = new RelayCommand(LoadProfilePicture);
            // tried camera also but not able to do it in my laptop
          //CapturePhotoCommand = new RelayCommand(CapturePhoto);
        }

    

        public void LoadProfilePicture()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg";
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                NewUser.ProfilePicture = File.ReadAllBytes(filePath);
                OnPropertyChanged(nameof(NewUser)); 
            }
        }

        private void SaveUser()
        {
            {

                //MessageBox.Show("enered");
                string c = "Data source = KRISHNA\\sqlexpress; Initial catalog = SagarDB; Integrated security = true";
                SqlConnection scon = new SqlConnection(c);
                //MessageBox.Show("Success");

                try
                {
                    scon.Open();

                    string sql = "INSERT INTO Users (Name, Age, DateOfBirth, ContactNumber, ProfilePicture) VALUES (@Name, @Age, @DateOfBirth, @ContactNumber, @ProfilePicture)";
                           
                    SqlCommand command = new SqlCommand(sql, scon);
                    command.Parameters.AddWithValue("@Name", NewUser.Name);
                    command.Parameters.AddWithValue("@Age", NewUser.Age);
                    command.Parameters.AddWithValue("@DateOfBirth", NewUser.DateOfBirth);
                    command.Parameters.AddWithValue("@ContactNumber", NewUser.ContactNumber);
                    command.Parameters.AddWithValue("@ProfilePicture", NewUser.ProfilePicture);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Image uploaded successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error uploading image: {ex.Message}");
                }
                finally
                {
                    scon.Close();
                }
            }
        }
        

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
